package controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.Auto;
import model.MemorySlot;

public class GCController {

    @FXML private FlowPane memoryGrid;
    @FXML private Button botaoAutomatico;
    @FXML private TextFlow console;
    @FXML private ScrollPane scrollPane;

    private List<MemorySlot> slots;
    private List<MemorySlot> slotsPercorridos;
    private List<MemorySlot> slotsAlocados;
    private List<MemorySlot> slotsRemovidos;

    private Auto automatico;
    private Boolean automaticoOn = false;

    @FXML
    public void initialize() {
        slots = new ArrayList<>();
        slotsPercorridos = new ArrayList<>();
        slotsAlocados = new ArrayList<>();
        slotsRemovidos = new ArrayList<>();

        Platform.runLater(this::construirSlots);
    }

    public void construirSlots(){
        for (Node node : memoryGrid.getChildren()) {
            if (node instanceof StackPane) {
                StackPane stack = (StackPane) node;
                Rectangle rect = null;
                Text txt  = null;
                Label lbl = null;

                for (Node inner : stack.getChildren()) {
                    if (inner instanceof Rectangle) rect = (Rectangle) inner;
                    else if (inner instanceof Label) lbl = (Label) inner;
                    else if (inner instanceof Text)  txt  = (Text) inner;
                }

                if (rect != null && txt != null && lbl != null) {
                    slots.add(new MemorySlot(rect, lbl, txt));
                } else {
                    System.err.println("StackPane sem filhos esperados.");
                }
            }
        }
    }

    @FXML
    public void alocar() {
        while (true) {
            MemorySlot slot = slots.get(new Random().nextInt(slots.size()));

            if(!slotsPercorridos.contains(slot)){
                slotsPercorridos.add(slot);
            }

            if (Color.WHITE.equals(slot.getRect().getFill())) {
                slotsAlocados.add(slot);
                slot.getRect().setFill(Color.LIMEGREEN);
                mensagemConsole("[INFO] Alocou memória no espaço " + slot.getCode(), Color.LIMEGREEN);
                break;
            } else if (slotsPercorridos.size() >= slots.size()){
                mensagemConsole("[INFO] Sem espaço na memória " + slot.getCode(), Color.BLACK);
                break;
            }
        }
    }

    @FXML
    public void removerReferencia() {
        while (!slotsAlocados.isEmpty()) {
            MemorySlot slot = slotsAlocados.get(new Random().nextInt(slotsAlocados.size()));

            if (Color.LIMEGREEN.equals(slot.getRect().getFill())) {
                slotsAlocados.remove(slot);
                slotsRemovidos.add(slot);
                slot.getRect().setFill(Color.RED);
                mensagemConsole("[INFO] Removeu referência à memória no espaço " + slot.getCode(), Color.RED);
                break;
            }
        }
    }

    @FXML
    public void executarGC() {
        if(slotsRemovidos.isEmpty()){
            mensagemConsole("[INFO] Garbage collector não encontrou nenhum lixo", Color.BLACK);
        }
        for (MemorySlot slot : slotsRemovidos) {
            slotsPercorridos.remove(slot);
            slot.getRect().setFill(Color.WHITE);
            slot.setCounter(0);
            slot.setCounterText();
            mensagemConsole("[INFO] Garbage collector rodou no espaço " + slot.getCode(), Color.BLACK);
        }
        for (MemorySlot slot : slotsAlocados){
            slot.setCounter(slot.incrementCounter());
            slot.setCounterText();
        }
        slotsRemovidos.clear();
    }

    private void mensagemConsole(String mensagem, Color cor) {
        Platform.runLater(() -> {
            Text linha = new Text(mensagem + "\n");
            linha.setFill(cor);
            linha.setStyle("-fx-font-family: Consolas; -fx-font-size: 12;");
            console.getChildren().add(linha);
            descerScrollPane();
        });
    }
    

    @FXML
    public void modoAutomatico() {
        System.out.println("[INFO] entrou no modoAutomatico");

        if(!automaticoOn){
            automaticoOn = true;
            automatico = new Auto(this);
            automatico.start();
        } else {
            automaticoOn = false;
            automatico.desligarThread();
        }
    }

    @FXML
    public void descerScrollPane(){

        Platform.runLater(() -> scrollPane.setVvalue(32));
    }

}
