package controller; // Troque pelo seu pacote real

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.Auto;

public class GCController {

    @FXML
    private FlowPane memoryGrid;

    @FXML private TextArea console;
    @FXML private Button botaoAutomatico;

    private List<Rectangle> blocos;
    private List<Rectangle> blocosVerdes;
    private List<Rectangle> blocosVermelhos;
    private List<Rectangle> blocosPercorridos;

    private Auto automatico;
    private Boolean automaticoOn = false;

    @FXML
    public void initialize() {
        blocosPercorridos = new ArrayList<>();
        blocosVerdes = new ArrayList<>();
        blocosVermelhos = new ArrayList<>();
        blocos = new ArrayList<>();

        //automatico = new Auto(this);


        for (javafx.scene.Node node : memoryGrid.getChildren()) {
            if (node instanceof StackPane) {
                StackPane stack = (StackPane) node;
                for (javafx.scene.Node innerNode : stack.getChildren()) {
                    if (innerNode instanceof Rectangle) {
                        blocos.add((Rectangle) innerNode);
                    }
                }
            }
        }
    }

    @FXML
    public void alocar() {
        while (blocosPercorridos.size() < blocos.size()) {
            Rectangle elem = blocos.get(new Random().nextInt(blocos.size()));

            if(!blocosPercorridos.contains(elem)){
                blocosPercorridos.add(elem);
            }

            if (Color.WHITE.equals(elem.getFill())) {
                blocosVerdes.add(elem);
                elem.setFill(Color.LIMEGREEN);
                String codigo = receberCodigoMemoria(elem);
                mensagemConsole("Alocou memória no espaço " + codigo);
                break;
            }

            
        }
    }

    @FXML
    public void removerReferencia() {
        while (blocosVerdes.size() != 0) {
            Rectangle elem = blocosVerdes.get(new Random().nextInt(blocosVerdes.size()));

            if (Color.LIMEGREEN.equals(elem.getFill())) {
                blocosVerdes.remove(elem);
                blocosVermelhos.add(elem);
                elem.setFill(Color.RED);
                String codigo = receberCodigoMemoria(elem);
                mensagemConsole("Removeu referencia a memória no espaço " + codigo);
                break;
            }
        }
    }

    @FXML
    public void executarGC() {
        for (Rectangle bloco : blocosVermelhos) {
            blocosPercorridos.remove(bloco);
            bloco.setFill(Color.WHITE);
            String codigo = receberCodigoMemoria(bloco);
            mensagemConsole("Garbage collector rodou no espaço " + codigo);
        }
        blocosVermelhos.clear();
    }


    @FXML
    private String receberCodigoMemoria(Rectangle memoria) {
        if (memoria.getParent() instanceof StackPane) {
            StackPane stack = (StackPane) memoria.getParent();
            for (javafx.scene.Node node : stack.getChildren()) {
                if (node instanceof Label) {
                    return ((Label) node).getText();
                }
            }
        }
        return " ";
    }

    @FXML
    private void mensagemConsole(String mensagem) {

        console.appendText(mensagem + "\n");
    }
    
    @FXML
    public void modoAutomatico() {

        System.out.println("entrou no modoAutomatico");
        
        if(!automaticoOn){

            automaticoOn = true;

            automatico = new Auto(this);
            automatico.start();
        }else if(automaticoOn){

            automaticoOn = false;
            automatico.desligarThread();
            
        }

    }
}
