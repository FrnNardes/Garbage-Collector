# Garbage-Collector
Simulação visual do Garbage Collector em JavaFX
