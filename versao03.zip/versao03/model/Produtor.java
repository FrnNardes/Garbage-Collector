package model;

import controller.TrocarTelasController;

public class Produtor extends Thread{

    int item;
    private TrocarTelasController controller = new TrocarTelasController();

    //construtor
    public Produtor(TrocarTelasController controller){

        this.controller = controller;
    }

    //metodo run da thread
    @Override
    public void run() {
        while (true) { 
    
          try {

            //confere se ha espaço no Buffer para produzir
            TrocarTelasController.vazio.acquire();
            System.out.println("Produtor deu down no vazio");
            //confere se eh possivel acessar a regiao critica
            TrocarTelasController.mutex.acquire();
            System.out.println("Produtor deu down no mutex");
            //produz item
            controller.ProduzirItem();
            TrocarTelasController.mutex.release();
            System.out.println("Produtor deu up no mutex");
            TrocarTelasController.cheio.release();
            System.out.println("Produtor deu up no cheio");

            sleep(2000); // responsavel pela animacao
          } catch (InterruptedException e) {
            e.printStackTrace();
          }
        }
      }
      
      
    //metodos

    //gambiarra da thread
    public void sleepThread(){

      try {
        sleep(1000);
      } catch (InterruptedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }

    
    
}
