package model;

//import controller.TelaSimulacaoController;
import controller.TrocarTelasController;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
//import javafx.application.Platform;
//import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
//import java.util.concurrent.Semaphore;

public class Consumidor extends Thread {

  int item;
  private TrocarTelasController controller = new TrocarTelasController();

  private ImageView imagem_consumidor;

  private ImageView consumidorMorrendo;

  // imagem do consumidor andando
  private String consumidor_andando = getClass().getResource("../img/consumidor_andando.gif").toExternalForm();

  // imagem do consumidor parado
  private String consumidor_parado = getClass().getResource("../img/consumidor_parado.gif").toExternalForm();

  private Image imagem_consumidor_andando = new Image(consumidor_andando);

  private Image imagem_consumidor_parado = new Image(consumidor_parado);

  private Image ritual01 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual02 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual03 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual04 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual05 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual06 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual07 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual08 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual09 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual10 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual11 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual12 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual13 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual14 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual15 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual16 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual17 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());
  private Image ritual18 = new Image(getClass().getResource("../img/consumidor_morrendo/morendo01.png").toExternalForm());


  private double velocidadeConsumidor;
  private Slider sliderConsumidor;

  private int bufferEscolhido;

  // construtor
  public Consumidor(TrocarTelasController controller, ImageView imagem_consumidor, ImageView consumidor_morrendo, Slider sliderConsumidor) {

    this.controller = controller;
    this.imagem_consumidor = imagem_consumidor;
    this.sliderConsumidor = sliderConsumidor;
    this.consumidorMorrendo = consumidor_morrendo;

  }

  // metodo run da thread
  @Override
  public void run() {
    while (true) {

      try {

        TrocarTelasController.cheio.acquire();

        TrocarTelasController.mutex.acquire();

        bufferEscolhido = controller.escolherBuffer();
        caminharBuffer(bufferEscolhido);
        controller.ConsumirItem();

        TrocarTelasController.mutex.release();

        TrocarTelasController.vazio.release();


        retornarPentagrama(bufferEscolhido);

        sleep(4000); // responsavel pela animacao
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }

  // metodos

  // *********** METODOS RELACIONADOS A MOVIMENTACAO DO CONSUMIDOR ***********

    /**************************************************************
   * Metodo: caminharBuffer01
   * Funcao: Responsavel pela movimentação do consumidor ate o buffer 01
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void caminharBuffer(int opcaoBuffer){

    switch(opcaoBuffer){

      case 0: //buffer 01

        caminharBuffer01();
      break;
      case 1: //buffer 02
        caminharBuffer02();
      break;
      case 2: //buffer 03
        caminharBuffer03();
      break;
      case 3: //buffer 04
        caminharBuffer04();
      break;
      case 4: //buffer 05
        caminharBuffer05();
      break;
    }
  }

    /**************************************************************
   * Metodo: retornarPentagrama
   * Funcao: Responsavel pela movimentação do consumidor ate o pentagrama, partindo do buffer adquirido
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  public void retornarPentagrama(int opcaoBuffer){

    switch(opcaoBuffer){

      case 0: //Buffer 01
        voltarParaPentagrama01();
      break;
      case 1: //Buffer 02
        voltarParaPentagrama02();
      break;
      case 2: //Buffer 03
        voltarParaPentagrama03();
      break;
      case 3: //Buffer 04
        voltarParaPentagrama04();
      break;
      case 4: //Buffer 05
        voltarParaPentagrama05();
      break;
    }


  }
  
  /**************************************************************
   * Metodo: caminharBuffer01
   * Funcao: Responsavel pela movimentação do consumidor ate o buffer 01
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void caminharBuffer01() {
    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() > 300) {

      if (this.imagem_consumidor.getLayoutX() > 500) { // anda reto

        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5);

      } else if (this.imagem_consumidor.getLayoutX() > 400) {

        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5);
        this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() - 7);

      } else if (this.imagem_consumidor.getLayoutX() > 300) {

        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5);
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: caminharBuffer02
   * Funcao: Responsavel pela movimentação do consumidor ate o buffer 02
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void caminharBuffer02() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() > 253) {

      if (this.imagem_consumidor.getLayoutX() > 500) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      } else if (this.imagem_consumidor.getLayoutX() > 440) {

        Platform.runLater(() -> {
          this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5);
          this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() - 5);
        });
      } else if (this.imagem_consumidor.getLayoutX() > 253) {
        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: caminharBuffer03
   * Funcao: Responsavel pela movimentação do consumidor ate o buffer 03
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void caminharBuffer03() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() > 315) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setScaleX(-1);
        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5);
      });

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: caminharBuffer04
   * Funcao: Responsavel pela movimentação do consumidor ate o buffer 04
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void caminharBuffer04() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() > 253) {

      if ((this.imagem_consumidor.getLayoutY() < 190) && (this.imagem_consumidor.getLayoutX() > 253)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 191) && (this.imagem_consumidor.getLayoutX() > 253)) {
        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));

      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: caminharBuffer05
   * Funcao: Responsavel pela movimentação do consumidor ate o buffer 05
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void caminharBuffer05() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() > 253) {

      if ((this.imagem_consumidor.getLayoutY() < 270) && (this.imagem_consumidor.getLayoutX() > 253)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 271) && (this.imagem_consumidor.getLayoutX() > 253)) {
        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));

      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: voltarParaPentagrama01
   * Funcao: Responsavel pela movimentação do consumidor ate o pentagrama a partir
   * do buffer01
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void voltarParaPentagrama01() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() < 680) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setScaleX(1);
        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);

      });

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();
    controller.atualizarPentagrama();

    while (this.imagem_consumidor.getLayoutX() > 611) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setImage(imagem_consumidor_andando);
        this.imagem_consumidor.setScaleX(-1);
      });

      if ((this.imagem_consumidor.getLayoutY() <= 50) && (this.imagem_consumidor.getLayoutX() > 611)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 51) && (this.imagem_consumidor.getLayoutX()) > 611) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: voltarParaPentagrama02
   * Funcao: Responsavel pela movimentação do consumidor ate o pentagrama a partir
   * do buffer02
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void voltarParaPentagrama02() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_andando));

    while (this.imagem_consumidor.getLayoutX() < 680) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setScaleX(1);
        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);

      });

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();
    controller.atualizarPentagrama();

    while (this.imagem_consumidor.getLayoutX() > 611) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setImage(imagem_consumidor_andando);
        this.imagem_consumidor.setScaleX(-1);
      });

      if ((this.imagem_consumidor.getLayoutY() <= 50) && (this.imagem_consumidor.getLayoutX() > 611)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 51) && (this.imagem_consumidor.getLayoutX()) > 611) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: voltarParaPentagrama03
   * Funcao: Responsavel pela movimentação do consumidor ate o pentagrama a partir
   * do buffer03
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void voltarParaPentagrama03() {

    Platform.runLater(() -> {
      this.imagem_consumidor.setScaleX(1);
      this.imagem_consumidor.setImage(imagem_consumidor_andando);
    
    });

    while (this.imagem_consumidor.getLayoutX() < 620) {

      Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5));
      sleepThread(sliderConsumidor.getValue());
    }

    while ((this.imagem_consumidor.getLayoutX() <= 690) && (this.imagem_consumidor.getLayoutY() >= -20)) {

      Platform.runLater(() -> {

        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);
        this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() - 5);

      });
      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();
    controller.atualizarPentagrama();

    while (this.imagem_consumidor.getLayoutX() > 611) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setImage(imagem_consumidor_andando);
        this.imagem_consumidor.setScaleX(-1);
      });

      if ((this.imagem_consumidor.getLayoutY() <= 50) && (this.imagem_consumidor.getLayoutX() > 611)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 51) && (this.imagem_consumidor.getLayoutX()) > 611) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: voltarParaPentagrama04
   * Funcao: Responsavel pela movimentação do consumidor ate o pentagrama a partir
   * do buffer04
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void voltarParaPentagrama04() {

    Platform.runLater(() -> {
      this.imagem_consumidor.setScaleX(1);
      this.imagem_consumidor.setImage(imagem_consumidor_andando);
    
    });

    while (this.imagem_consumidor.getLayoutX() < 311) {

      Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5));
      sleepThread(sliderConsumidor.getValue());
    }

    while ((this.imagem_consumidor.getLayoutX() <= 690) && (this.imagem_consumidor.getLayoutY() >= -20)) {

      Platform.runLater(() -> {

        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);
        this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() - 5);

      });
      sleepThread(sliderConsumidor.getValue());
    }

    while (this.imagem_consumidor.getLayoutX() < 680) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setScaleX(1);
        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);

      });

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();
    controller.atualizarPentagrama();

    while (this.imagem_consumidor.getLayoutX() > 611) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setImage(imagem_consumidor_andando);
        this.imagem_consumidor.setScaleX(-1);
      });

      if ((this.imagem_consumidor.getLayoutY() <= 50) && (this.imagem_consumidor.getLayoutX() > 611)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 51) && (this.imagem_consumidor.getLayoutX()) > 611) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }

  /**************************************************************
   * Metodo: voltarParaPentagrama05
   * Funcao: Responsavel pela movimentação do consumidor ate o pentagrama a partir
   * do buffer05
   * Parametros: nulo
   * Retorno: void
   ***************************************************************/
  private void voltarParaPentagrama05() {

    Platform.runLater(() -> {
      this.imagem_consumidor.setScaleX(1);
      this.imagem_consumidor.setImage(imagem_consumidor_andando);
    
    });

    while (this.imagem_consumidor.getLayoutX() < 211) {

      Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5));
      sleepThread(sliderConsumidor.getValue());
    }

    while ((this.imagem_consumidor.getLayoutX() <= 690) && (this.imagem_consumidor.getLayoutY() >= -20)) {

      Platform.runLater(() -> {

        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);
        this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() - 5);

      });
      sleepThread(sliderConsumidor.getValue());
    }

    while (this.imagem_consumidor.getLayoutX() < 680) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setScaleX(1);
        this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() + 5);

      });

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();
    controller.atualizarPentagrama();

    while (this.imagem_consumidor.getLayoutX() > 611) {

      Platform.runLater(() -> {
        this.imagem_consumidor.setImage(imagem_consumidor_andando);
        this.imagem_consumidor.setScaleX(-1);
      });

      if ((this.imagem_consumidor.getLayoutY() <= 50) && (this.imagem_consumidor.getLayoutX() > 611)) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutY(this.imagem_consumidor.getLayoutY() + 5));
      } else if ((this.imagem_consumidor.getLayoutY() == 51) && (this.imagem_consumidor.getLayoutX()) > 611) {

        Platform.runLater(() -> this.imagem_consumidor.setLayoutX(this.imagem_consumidor.getLayoutX() - 5));
      }

      sleepThread(sliderConsumidor.getValue());
    }

    repousoConsumidor();

  }


  //consumidor morrendo
  public void realizarRitual(){


    for(int i = 0; i < 18; i++){

      this.imagem_consumidor.setVisible(false);
      this.consumidorMorrendo.setVisible(false);

      switch(i){

        case 0:
        


      }
    }
  }


  

  // gambiarra do sleep da thread
  public void sleepThread(double velocidade) {

    try {
      Thread.sleep((long) (velocidade * 10));
    } catch (InterruptedException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  // gambiarra de parar o consumidor por alguns instantes de tempo
  public void repousoConsumidor() {

    Platform.runLater(() -> this.imagem_consumidor.setImage(imagem_consumidor_parado));
    sleepThread(sliderConsumidor.getValue());

    for (int i = 0; i < 12; i++) {

      sleepThread(sliderConsumidor.getValue());
    }
  }

  // getters e setters

  // get imagem do consumidor
  public ImageView getImagemConsumidor() {

    return this.imagem_consumidor;
  }

}
