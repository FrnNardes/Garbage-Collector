package Utils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Buffer {


    private int[] Buffer; //buffer a ser manipulado pelo produtor/consumidor
    private int tamanhoBuffer; //tamanho do Buffer
    private Queue <Integer> filaBuffer; //armazena a ordem de buffers que o consumidor deve acessar em sequencia(sincronizado com a geracao de itens)



    //construtor
    public Buffer(int N){

        //inicia o array Buffer
        Buffer = new int[N];
        this.tamanhoBuffer = N;
        filaBuffer = new LinkedList<>();

    }

    //metodos

    //inicializa o buffer com espaços vazios
    public void inicializarVazioBuffer(){

        for(int i = 0; i < this.tamanhoBuffer; i++){

            Buffer[i] = 0;
        }
    }

   


    //altera o estado do array, se estiver vazio, altera para cheio, se estiver cheio, altera para vazio
    public void ArmazenarItemIDBuffer(int posicao, int itemID){

        Buffer[posicao] = itemID;
    }

    //retorna o ID do item consumido pelo consumidor e atualiza o slot do buffer para vazio(0)
    public int RetirarItemIDBuffer(int posicao){

        int ID_Item = Buffer[posicao];

        Buffer[posicao] = 0;
        
        return ID_Item;
    }



    //produtor produz em um buffer aleatorio
    public int InserirBufferAleatorio(){

        ArrayList <Integer> posicoesLivres = new ArrayList<>();

        for(int i = 0; i < Buffer.length; i++){

            if(Buffer[i] == 0){

                posicoesLivres.add(i);
            }
        }

        Random rand = new Random();
        int indice_sorteado = rand.nextInt(posicoesLivres.size());
        int buffer_sorteado = posicoesLivres.get(indice_sorteado);

        return buffer_sorteado;
    }

    
    //metodos relacionados a fila do consumidor

    //adiciona um buffer na ordem da fila
    public void adicionarFilaBuffer(int buffer){

        this.filaBuffer.offer(buffer);
    }


    //remove o buffer que ja foi acessado pelo consumidor
    public Integer removerFilaBuffer(){
        return this.filaBuffer.poll();
    }


    
}
