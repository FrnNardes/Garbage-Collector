/*******************************************************************************************************
* Autor: Maick Vieira Alves
* Matricula: 202310196
* Inicio: 12/03/2025
* Ultima alteracao: 21/03/2025 
* Nome: TrocarTelasController
* Descricao: Controller das telas de menu e sobre. Essa classe eh a responsavel por controlar os 
* botoes e controla as trocas de telas do programa
******************************************************************************************************* */

package controller;

import javafx.application.Platform;

//import java.io.IOException;

//import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Node;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.image.ImageView;
//import javafx.scene.input.MouseEvent;
//import javafx.stage.Stage;
//import model.AviaoCarregamento;
import model.Consumidor;
import model.Produtor;

//biblioteca do semaforo
import java.util.concurrent.Semaphore;
//bibliotecas javaFX


import model.Consumidor;
import model.Produtor;
import Utils.Buffer;

public class TrocarTelasController {
  
  //private Stage janela;
  //private Scene cena;

  //produtor consumidor
  final static int tamanhoBuffer = 5;
  //semaforos
  public static Semaphore mutex = new Semaphore(1);
  public static Semaphore cheio = new Semaphore(0);
  public static Semaphore vazio = new Semaphore(tamanhoBuffer);

  @FXML ImageView imagem_consumidor;
  @FXML ImageView imagem_produtor;
  @FXML ImageView ConsumidorMorrendo;
  //relacionados a animacao dos buffers

  //buffer01
  @FXML ImageView pedestal01_01;
  @FXML ImageView pedestal01_02;
  @FXML ImageView pedestal01_03;
  @FXML ImageView pedestal01_04;
  @FXML ImageView pedestal01_05;
  @FXML ImageView produzindo01;
  @FXML ImageView item01;
  //buffer02
  @FXML ImageView pedestal02_01;
  @FXML ImageView pedestal02_02;
  @FXML ImageView pedestal02_03;
  @FXML ImageView pedestal02_04;
  @FXML ImageView pedestal02_05;
  @FXML ImageView produzindo02;
  @FXML ImageView item02;
  //buffer03
  @FXML ImageView pedestal03_01;
  @FXML ImageView pedestal03_02;
  @FXML ImageView pedestal03_03;
  @FXML ImageView pedestal03_04;
  @FXML ImageView pedestal03_05;
  @FXML ImageView produzindo03;
  @FXML ImageView item03;
  //buffer04
  @FXML ImageView pedestal04_01;
  @FXML ImageView pedestal04_02;
  @FXML ImageView pedestal04_03;
  @FXML ImageView pedestal04_04;
  @FXML ImageView pedestal04_05;
  @FXML ImageView produzindo04;
  @FXML ImageView item04;
  //buffer05
  @FXML ImageView pedestal05_01;
  @FXML ImageView pedestal05_02;
  @FXML ImageView pedestal05_03;
  @FXML ImageView pedestal05_04;
  @FXML ImageView pedestal05_05;
  @FXML ImageView produzindo05;
  @FXML ImageView item05;
  //Estados do Pentagrama
  @FXML ImageView pentagrama01;
  @FXML ImageView pentagrama02;
  @FXML ImageView pentagrama03;
  @FXML ImageView pentagrama04;
  @FXML ImageView pentagrama05;
  //Itens colocados no pentagrama
  @FXML ImageView vela_ritual01;
  @FXML ImageView vela_ritual02;
  @FXML ImageView vela_ritual03;
  @FXML ImageView vela_ritual04;
  @FXML ImageView vela_ritual05;
  @FXML ImageView boneco_voodoo;
  @FXML ImageView caveira_ritual01_01;
  @FXML ImageView caveira_ritual02_01;
  @FXML ImageView caveira_ritual03_01;
  @FXML ImageView caveira_ritual01_02;
  @FXML ImageView caveira_ritual02_02;
  @FXML ImageView caveira_ritual03_02;
  //sliders para controle de velocidade
  @FXML Slider sliderConsumidor;
  @FXML Slider sliderProdutor;

 

  private String itemVela = getClass().getResource("../img/vela01.png").toExternalForm();
  private String itemCaveira = getClass().getResource("../img/caveira01.png").toExternalForm();
  private String itemVooDoo = getClass().getResource("../img/boneco_voo_doo.png").toExternalForm();

  private Image imagem_vela = new Image(itemVela);

  private Image imagem_caveira = new Image(itemCaveira);

  private Image imagem_voodoo = new Image(itemVooDoo);

  Consumidor consumidor;
  Produtor produtor;
  Buffer buffer;

  ImageView[] ItensInvocados;
 
  int ItensJaInvocados = 0;
  int ID_ItemInvocado; //item invocado: 1 = velas, 2 = caveiras, 3 = velas para caveiras, 4 = boneco voodoo
  int posicaoBuffer; //buffer que sera invocado o item
  int ItemConsumido; //recebe o id do item consumido pelo consumidor


  //variaveis relacionadas ao controle do pentagrama
  int velas = 1;
  int caveiras = 1;
  int velasCaveiras = 1;
  int voodoo = 1;

  @FXML
    public void initialize() {

        buffer = new Buffer(tamanhoBuffer);
        buffer.inicializarVazioBuffer();

        consumidor = new Consumidor(this, imagem_consumidor, ConsumidorMorrendo, sliderConsumidor);
        produtor = new Produtor(this);

        consumidor.start();
        produtor.start();


    }

  //metodos

  //produzir Item
  public void ProduzirItem(){

    this.posicaoBuffer = buffer.InserirBufferAleatorio();
    
    switch(posicaoBuffer){

      case 0:
        ItemAserInvocado(item01);
        animarProducao(item01, produzindo01, pedestal01_01, pedestal01_02, pedestal01_03, pedestal01_04, pedestal01_05);

      break;
      case 1:
      ItemAserInvocado(item02);
        animarProducao(item02, produzindo02, pedestal02_01, pedestal02_02, pedestal02_03, pedestal02_04, pedestal02_05);

      break;
      case 2:
      ItemAserInvocado(item03);
        animarProducao(item03, produzindo03, pedestal03_01, pedestal03_02, pedestal03_03, pedestal03_04, pedestal03_05);
      
      break;
      case 3:
        ItemAserInvocado(item04);
        animarProducao(item04, produzindo04, pedestal04_01, pedestal04_02, pedestal04_03, pedestal04_04, pedestal04_05);

      break;
      case 4:
      ItemAserInvocado(item05);
        animarProducao(item05, produzindo05, pedestal05_01, pedestal05_02, pedestal05_03, pedestal05_04, pedestal05_05);

      break;
    }

    buffer.ArmazenarItemIDBuffer(posicaoBuffer, ID_ItemInvocado);
    buffer.adicionarFilaBuffer(posicaoBuffer);

}

//animacao de criar itens
public void animarProducao(ImageView item, ImageView produzindo, ImageView pedestal01, ImageView pedestal02, ImageView pedestal03, ImageView pedestal04, ImageView pedestal05){

  for(int i = 0; i < 9; i++){

    switch(i){

      case 0:
        Platform.runLater(() -> {
          item.setOpacity(0);
          item.setVisible(true);
          produzindo.setVisible(true);
          item.setOpacity(0.10);
        });
        break;

      case 2:
        Platform.runLater(() -> {
          item.setOpacity(0.20);
          pedestal02.setVisible(true);
          pedestal01.setVisible(false);
        });
        
        break;
      case 3:
        Platform.runLater(() -> {
          item.setOpacity(0.40);
          pedestal03.setVisible(true);
          pedestal02.setVisible(false);
        });
        break;
      case 4:
        Platform.runLater(() -> {
          item.setOpacity(0.60);
          pedestal04.setVisible(true);
          pedestal03.setVisible(false);
        });
        break;
      case 5:
        item.setOpacity(0.80);

        break;
      case 6:
        Platform.runLater(() -> {
          item.setOpacity(1);
          pedestal05.setVisible(true);
          pedestal04.setVisible(false);
        });
        break;
      case 7:
        break;
      case 8:
        Platform.runLater(() -> {
          produzindo.setVisible(false);
        });
        break;
    }

    produtor.sleepThread();
  }

}


//array dos itens do pentagrama
public void ItemAserInvocado(ImageView item){

  if(this.ItensJaInvocados <= 4){ //velas

    Platform.runLater(() -> item.setImage(imagem_vela));
    this.ID_ItemInvocado = 1;
    this.ItensJaInvocados++;

  }else if(this.ItensJaInvocados <= 7){ //caveiras

    Platform.runLater(() -> item.setImage(imagem_caveira));
    this.ID_ItemInvocado = 2;
    this.ItensJaInvocados++;
    
  }else if(this.ItensJaInvocados <= 10){ //velas das caveiras

    Platform.runLater(() -> item.setImage(imagem_vela));
    this.ID_ItemInvocado = 3;
    this.ItensJaInvocados++;

  }else if(this.ItensJaInvocados <=11){ //voodoo

    Platform.runLater(() -> item.setImage(imagem_voodoo));
    this.ID_ItemInvocado = 4;
    this.ItensJaInvocados = 0;
  }

  produtor.sleepThread();

}

//escolher aleatoriamente um buffer para acessar
public int escolherBuffer(){

  int bufferEscolhido = buffer.removerFilaBuffer();

  return bufferEscolhido;
}


//consumir item
public void ConsumirItem(){


  this.ItemConsumido = buffer.RetirarItemIDBuffer(posicaoBuffer); //recebe o ID do item e atualiza o Buffer


  switch(posicaoBuffer){

    case 0: //buffer 01
      item01.setVisible(false);
      pedestal01_01.setVisible(true);
      pedestal01_05.setVisible(false);
    break;
    case 1: //buffer 02
      item02.setVisible(false);
      pedestal02_01.setVisible(true);
      pedestal02_05.setVisible(false);
    break;
    case 2: //buffer 03
      item03.setVisible(false);
      pedestal03_01.setVisible(true);
      pedestal03_05.setVisible(false);
    break;
    case 3: //buffer 04
      item04.setVisible(false);
      pedestal04_01.setVisible(true);
      pedestal04_05.setVisible(false);
    break;
    case 4: //buffer 05
      item05.setVisible(false);
      pedestal05_01.setVisible(true);
      pedestal05_05.setVisible(false);
    break;
  }
}


//metodos relacionados a atualizacao do pentagrama
public void atualizarPentagrama(){


    switch(ItemConsumido){

      case 1: //velas

        if(velas == 1){
          Platform.runLater(() -> vela_ritual01.setVisible(true));
          velas++;
        }else if(velas == 2){
          Platform.runLater(() -> vela_ritual02.setVisible(true));
          velas++;
        }else if(velas == 3){
          Platform.runLater(() -> vela_ritual03.setVisible(true));
          velas++;
        }else if(velas == 4){
          Platform.runLater(() -> vela_ritual04.setVisible(true));
          velas++;
        }else if(velas == 5){
          Platform.runLater(() -> vela_ritual05.setVisible(true));
        }
      break;
      case 2: //Caveiras
        
        if(caveiras == 1){
          Platform.runLater(() -> caveira_ritual01_01.setVisible(true));
          caveiras++;
        }else if(caveiras == 2){
          Platform.runLater(() -> caveira_ritual02_01.setVisible(true));
          caveiras++;
        }else if(caveiras == 3){
          Platform.runLater(() -> caveira_ritual03_01.setVisible(true));
        }
      break;
      case 3: //velas das caveiras
        
        if(velasCaveiras == 1){
          Platform.runLater(() -> caveira_ritual01_02.setVisible(true));
          Platform.runLater(() -> caveira_ritual01_01.setVisible(false));
          velasCaveiras++;
        }else if(velasCaveiras == 2){
          Platform.runLater(() -> caveira_ritual02_02.setVisible(true));
          Platform.runLater(() -> caveira_ritual02_01.setVisible(false));
          velasCaveiras++;
        }else if(velasCaveiras == 3){
          Platform.runLater(() -> caveira_ritual03_02.setVisible(true));
          Platform.runLater(() -> caveira_ritual03_01.setVisible(false));
        }
      break;
      case 4: //voodoo

        if(voodoo == 1){

          Platform.runLater(() -> boneco_voodoo.setVisible(true));
        }
        
    }
    consumidor.repousoConsumidor();
}


//ritual completo
public void realizarRitual(){


}

  // Fim dos metodos


 

}



